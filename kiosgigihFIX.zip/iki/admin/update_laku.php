<?php 
include 'config.php';
$id=$_GET['id'];
$tgl=$_GET['tgl'];
$nama=$_GET['nama'];
$harga=$_GET['harga'];
$jumlah=$_GET['jumlah'];

mysql_query("update barang_laku set nama='$nama', jenis='$jenis', suplier='$suplier', modal='$modal', harga='$harga', jumlah='$jumlah' where id='$id'");
header("location:barang_laku.php");

?>