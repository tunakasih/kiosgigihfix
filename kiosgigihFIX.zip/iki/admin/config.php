<?php 
mysql_connect("localhost","id8451471_kiosgigih","kiosgigih");
mysql_select_db("id8451471_kios");
?>